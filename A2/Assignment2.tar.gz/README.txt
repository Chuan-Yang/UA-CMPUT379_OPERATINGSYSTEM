Client Interface:
1: check the information in an entry 
    1.1 enter the number of the entry that you want to check    
2: update the information in an entry without encryption
    2.1 enter the number of the entry   
    2.2 enter the length of the string
    2.3 enter the string
3: update the information in an entry with encryption
    3.1 enter the number of the entry   
    3.2 enter the length of the string
    3.3 enter the string 
4: clean the information in an entry    
    4.1 enter the number of the entry
5: exit 
    3.1 enter exit or <control-c>


The server will send back a message and will be dispalyed.
After all done, will do sleep(2) for waiting and testing.